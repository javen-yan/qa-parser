/*
 * Implementation of 'native' and 'python' selectors
 *
 * XXX: Implement GC protocol in these classes
 */
#include "pyobjc.h"

#include <objc/Object.h>

NS_ASSUME_NONNULL_BEGIN

PyObject* PyObjCSelector_Type;
PyObject* PyObjCNativeSelector_Type;
PyObject* PyObjCPythonSelector_Type;

static char* _Nullable pysel_default_signature(SEL selector, PyObject* callable);
static PyObject* _Nullable pysel_new(PyTypeObject* type, PyObject* _Nullable args,
                                     PyObject* _Nullable kwds);

static int
sel_validate_self(PyObjCSelector* sel, PyObject* self)
{
    assert(sel->sel_class != Nil);
    PyObject* myClass = PyObjCClass_New(sel->sel_class);
    if (unlikely(myClass == NULL)) { // LCOV_BR_EXCL_LINE
        return -1;                   // LCOV_EXCL_LINE
    }

    assert(PyType_Check(myClass));

    if (unlikely(sel->sel_flags & PyObjCSelector_kCLASS_METHOD)) {
        /* Class method */
        if (!PyType_Check(self)
            || (!PyType_IsSubtype((PyTypeObject*)self, (PyTypeObject*)myClass)
                && !PyObject_IsInstance(myClass, self))) {
            PyErr_Format(PyExc_TypeError, "Expecting subclass of %s as self, got %R",
                         class_getName(sel->sel_class), self);
            Py_CLEAR(myClass);
            return -1;
        }

    } else {
        /* Instance method */

        if (!(PyObject_IsInstance(self, myClass)
              || (PyUnicode_Check(self)
                  && PyObjC_class_isSubclassOf(sel->sel_class, [NSString class])))) {

            PyErr_Format(PyExc_TypeError,
                         "Expecting instance of %s as self, got one "
                         "of %s",
                         class_getName(sel->sel_class), Py_TYPE(self)->tp_name);
            Py_DECREF(myClass);
            return -1;
        }
    }
    Py_CLEAR(myClass);
    return 0;
}

/*
 * Base type for objective-C selectors
 *
 * selectors are callable objects with the following attributes:
 * - 'signature': The objective-C signature of the method
 * - 'selector': The name in the objective-C runtime
 */

PyObjCMethodSignature* _Nullable PyObjCSelector_GetMetadata(PyObject* _self)
{
    assert(PyObjCSelector_Check(_self));

    if (PyObjCBoundSelector_Check(_self)) {
        return PyObjCSelector_GetMetadata(PyObjCBoundSelector_SELECTOR(_self));
    }

    PyObjCSelector* self = (PyObjCSelector*)_self;

    if (self->sel_methinfo != NULL && self->sel_mappingcount != PyObjC_MappingCount) {
        Py_BEGIN_CRITICAL_SECTION(self);
        Py_CLEAR(self->sel_methinfo);
        /* XXX: This should also reset the CIF! */
        Py_END_CRITICAL_SECTION();
    }

    PyObjCMethodSignature* result;
    Py_BEGIN_CRITICAL_SECTION(self);
    result = self->sel_methinfo;
    Py_XINCREF(result);
    Py_END_CRITICAL_SECTION();
    if (result != NULL) {
        return result;
    }

    /*
     * Free threading: calculate the method signature
     * without locking this value, this can cause a race
     * between threads.
     *
     * Hence the additional test for a non-NULL value before
     * setting the value.
     *
     * Using 'to_clear' is avoids a DECREF within the critical
     * section, which in general can invoke arbitrary code (even
     * though this shouldn't happen with method signature
     * objects).
     */

    PyObjCMethodSignature* to_clear;
    result = to_clear = PyObjCMethodSignature_ForSelector(
        self->sel_class, (self->sel_flags & PyObjCSelector_kCLASS_METHOD) != 0,
        self->sel_selector, self->sel_python_signature, PyObjCNativeSelector_Check(self));

    if (unlikely(result == NULL)) // LCOV_BR_EXCL_LINE
        return NULL;              // LCOV_EXCL_LINE

    Py_BEGIN_CRITICAL_SECTION(self);
#ifdef Py_GIL_DISABLED
    if (self->sel_methinfo == NULL) {
#endif
        self->sel_methinfo     = result;
        self->sel_mappingcount = PyObjC_MappingCount;
        to_clear               = NULL;
#ifdef Py_GIL_DISABLED
    } else {
        result = self->sel_methinfo; //  LCOV_EXCL_LINE
    }
#endif

    Py_INCREF(result);

    Py_END_CRITICAL_SECTION();

    Py_CLEAR(to_clear);

    return result;
}

PyDoc_STRVAR(sel_metadata_doc,
             "__metadata__()\n" CLINIC_SEP
             "\nReturn a dict that describes the metadata for this method, including "
             "metadata for the 2 hidden ObjC parameters (self and _sel) ");
static PyObject* _Nullable sel_metadata(PyObject* self)
{
    int                    r;
    PyObjCMethodSignature* mi = PyObjCSelector_GetMetadata(self);
    if (unlikely(mi == NULL)) { // LCOV_BR_EXCL_LINE
        return NULL;            // LCOV_EXCL_LINE
    }

    PyObject* result = PyObjCMethodSignature_AsDict(mi);
    Py_CLEAR(mi);
    if (unlikely(result == NULL)) { // LCOV_BR_EXCL_LINE
        return NULL;                // LCOV_EXCL_LINE
    }

    r = PyDict_SetItem(result, PyObjCNM_classmethod,
                       (((PyObjCSelector*)self)->sel_flags & PyObjCSelector_kCLASS_METHOD)
                           ? Py_True
                           : Py_False);
    if (unlikely(r == -1)) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        Py_DECREF(result);
        return NULL;
        // LCOV_EXCL_STOP
    }

    r = PyDict_SetItem(result, PyObjCNM_hidden,
                       (((PyObjCSelector*)self)->sel_flags & PyObjCSelector_kHIDDEN)
                           ? Py_True
                           : Py_False);

    if (unlikely(r == -1)) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        Py_DECREF(result);
        return NULL;
        // LCOV_EXCL_STOP
    }

#if PY_VERSION_HEX >= 0x030f00a7
    PyObject* tmp = PyFrozenDict_New(result);
    Py_CLEAR(result);
    return tmp;

#else
    return result;
#endif
}

static PyMethodDef base_methods[] = {{.ml_name  = "__metadata__",
                                      .ml_meth  = (PyCFunction)sel_metadata,
                                      .ml_flags = METH_NOARGS,
                                      .ml_doc   = sel_metadata_doc},
                                     {
                                         .ml_name = NULL /* SENTINEL */
                                     }};

PyDoc_STRVAR(base_self_doc, "Always *None*");

static PyObject* _Nullable base_self(PyObject* _self __attribute__((__unused__)),
                                     void*     closure __attribute__((__unused__)))
{
    if (PyErr_Warn(PyExc_DeprecationWarning,
                   "using the *self* attribute on objc.native_selector or "
                   "objc.python_selector instances is deprecated")
        < 0) {
        return NULL;
    }
    Py_RETURN_NONE;
}

PyDoc_STRVAR(base_signature_doc, "Objective-C signature for the method");

static PyObject* _Nullable base_signature(PyObject* self,
                                          void*     closure __attribute__((__unused__)))
{
    PyObjCMethodSignature* methinfo = PyObjCSelector_GetMetadata(self);
    if (unlikely(methinfo == NULL)) { // LCOV_BR_EXCL_LINE
        return NULL;                  // LCOV_EXCL_LINE
    }

    PyObject* result = PyBytes_FromString(methinfo->signature);
    Py_CLEAR(methinfo);
    return result;
}

PyDoc_STRVAR(base_native_signature_doc, "original Objective-C signature for the method");

static PyObject*
base_native_signature(PyObject* _self, void* closure __attribute__((__unused__)))
{
    /* free-threading: no locking needed because sel_native_signature is constant after
     * initialization.
     */
    PyObjCSelector* self = (PyObjCSelector*)_self;
    if (unlikely(self->sel_native_signature == NULL)) { // LCOV_BR_EXCL_LINE
        // Cannot happen, leaving test in just in case...
        Py_RETURN_NONE; // LCOV_EXCL_LINE
    }

    return PyBytes_FromString(self->sel_native_signature);
}

static int
base_signature_setter(PyObject* _self, PyObject* newVal,
                      void* closure __attribute__((__unused__)))
{
    PyObjCNativeSelector* self = (PyObjCNativeSelector*)_self;
    char*                 t;

    if (newVal == NULL) {
        PyErr_SetString(PyExc_TypeError, "Cannot delete 'signature'");
        return -1;
    }

    if (!PyBytes_Check(newVal)) {
        PyErr_SetString(PyExc_TypeError, "signature must be byte string");
        return -1;
    }

    t = PyObjCUtil_Strdup(PyBytes_AsString(newVal));
    if (unlikely(t == NULL)) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        PyErr_NoMemory();
        return -1;
        // LCOV_EXCL_STOP
    }

    PyObjCMethodSignature* methinfo = NULL;
    Py_BEGIN_CRITICAL_SECTION(self);
    PyMem_Free((char*)self->base.sel_python_signature);
    self->base.sel_python_signature = t;

    if (self->base.sel_methinfo != NULL) {
        /* Native selector was changed, ensure the metadata gets updated */
        methinfo                = self->base.sel_methinfo;
        self->base.sel_methinfo = NULL;
    }
    Py_END_CRITICAL_SECTION();
    Py_CLEAR(methinfo);
    return 0;
}

PyDoc_STRVAR(base_hidden_doc,
             "If True the method is not directly accessible as an object attribute");

static PyObject*
base_hidden(PyObject* _self, void* closure __attribute__((__unused__)))
{
    /* Free-threading: needs atomic access? */
    if (((PyObjCSelector*)_self)->sel_flags & PyObjCSelector_kHIDDEN) {
        Py_RETURN_TRUE;
    } else {
        Py_RETURN_FALSE;
    }
}
static int
base_hidden_setter(PyObject* _self, PyObject* newVal,
                   void* closure __attribute__((__unused__)))
{
    if (newVal == NULL) {
        PyErr_SetString(PyExc_TypeError, "Cannot delete 'isHidden'");
        return -1;
    }

    int hidden = PyObject_IsTrue(newVal);
    if (hidden == -1) {
        return -1;
    }
    if (hidden) {
        Py_BEGIN_CRITICAL_SECTION(_self);
        ((PyObjCSelector*)_self)->sel_flags |= PyObjCSelector_kHIDDEN;
        Py_END_CRITICAL_SECTION();
    } else {
        Py_BEGIN_CRITICAL_SECTION(_self);
        ((PyObjCSelector*)_self)->sel_flags &= ~PyObjCSelector_kHIDDEN;
        Py_END_CRITICAL_SECTION();
    }
    return 0;
}

PyDoc_STRVAR(base_selector_doc, "Objective-C name for the method");

static PyObject*
base_selector(PyObject* _self, void* closure __attribute__((__unused__)))
{
    PyObjCSelector* self = (PyObjCSelector*)_self;
    return PyBytes_FromString(sel_getName(self->sel_selector));
}

PyDoc_STRVAR(base_name_doc, "Name for the method");

static PyObject* _Nullable base_name(PyObject* _self,
                                     void*     closure __attribute__((__unused__)))
{
    PyObjCSelector* self = (PyObjCSelector*)_self;

    return PyObjC_SELToPythonName(self->sel_selector);
}

PyDoc_STRVAR(base_class_doc, "Objective-C Class that defines the method");
static PyObject* _Nullable base_class(PyObject* _self,
                                      void*     closure __attribute__((__unused__)))
{
    PyObjCNativeSelector* self = (PyObjCNativeSelector*)_self;
    if (self->base.sel_class != nil) {
        return PyObjCClass_New(self->base.sel_class);
    }

    Py_RETURN_NONE;
}

PyDoc_STRVAR(base_class_method_doc, "True if this is a class method, False otherwise");

static PyObject*
base_class_method(PyObject* _self, void* closure __attribute__((__unused__)))
{
    PyObjCNativeSelector* self = (PyObjCNativeSelector*)_self;
    if (0 != (self->base.sel_flags & PyObjCSelector_kCLASS_METHOD)) {
        Py_RETURN_TRUE;
    } else {
        Py_RETURN_FALSE;
    }
}

PyDoc_STRVAR(base_required_doc, "True if this is a required method, False otherwise");

static PyObject*
base_required(PyObject* _self, void* closure __attribute__((__unused__)))
{
    PyObjCNativeSelector* self = (PyObjCNativeSelector*)_self;
    if (0 != (self->base.sel_flags & PyObjCSelector_kREQUIRED)) {
        Py_RETURN_TRUE;
    } else {
        Py_RETURN_FALSE;
    }
}

static PyObject* _Nullable base_descr_get(PyObject* _meth, PyObject* _Nullable obj,
                                          PyObject* _Nullable class)
{
    assert(PyObjCNativeSelector_Check(_meth) || PyObjCPythonSelector_Check(_meth));
    PyObjCSelector* meth = (PyObjCSelector*)_meth;

    if (meth->sel_flags & PyObjCSelector_kCLASS_METHOD) {
        if (class != nil && PyType_Check(class)
            && PyType_IsSubtype((PyTypeObject*)class, &PyObjCClass_Type)) {
            obj = PyObjCClass_ClassForMetaClass(class);
            if (unlikely(obj == NULL)) { // LCOV_BR_EXCL_LINE
                // LCOV_EXCL_START
                PyErr_SetString(PyObjCExc_InternalError,
                                "Cannot find class for metaclass");
                return NULL;
                // LCOV_EXCL_STOP
            }
        } else {
            if (unlikely(class == NULL)) { // LCOV_BR_EXCL_LINE
                // LCOV_EXCL_START
                PyErr_SetString(PyExc_TypeError, "class is NULL");
                return NULL;
                // LCOV_EXCL_STOP
            }
            obj = class;
        }
    } else {
        if (!obj || (obj && PyObjCClass_Check(obj))) {
            Py_INCREF(_meth);
            return _meth;
        }
    }
    return PyObjCBoundSelector_New(obj, meth);
}

static void
sel_dealloc(PyObject* object)
{
    PyObjCSelector* self = (PyObjCSelector*)object;
    Py_CLEAR(self->sel_methinfo);

    PyMem_Free((char*)self->sel_python_signature);

    if (self->sel_native_signature != NULL) {
        PyMem_Free((char*)self->sel_native_signature);
        self->sel_native_signature = NULL;
    }
    PyTypeObject* tp = Py_TYPE(object);
    PyObject_Del(object);
    Py_DECREF(tp);
}

PyDoc_STRVAR(base_selector_type_doc,
             "selector(function, [, selector] [, signature] [, isClassMethod=0]\n"
             "    [, isRequired=True]) -> selector\n"
             "\n"
             "Return an Objective-C method from a function. The other arguments \n"
             "specify attributes of the Objective-C method.\n"
             "\n"
             "function:\n"
             "  A function object with at least one argument. The first argument will\n"
             "  be used to pass 'self'. This argument may be None when defining an\n"
             "  informal_protocol object. The function must not be a ``staticmethod``\n"
             "  instance. \n"
             "\n"
             "selector:\n"
             "  The name of the Objective-C method. The default value of this\n"
             "  attribute is the name of the function, with all underscores replaced\n"
             "  by colons.\n"
             "\n"
             "signature:\n"
             "  Method signature for the Objective-C method. This should be a raw\n"
             "  Objective-C method signature, including specifications for 'self' and\n"
             "  '_cmd'. The default value a signature that describes a method with\n"
             "  arguments of type 'id' and a return-value of the same type.\n"
             "\n"
             "isClassMethod:\n"
             "  True if the method is a class method, false otherwise. The default is \n"
             "  False, unless the function is an instance of ``classmethod``.\n"
             "\n"
             "isRequired:\n"
             "  True if this is a required method in an informal protocol, False\n"
             "  otherwise. The default value is 'True'. This argument is only used\n"
             "  when defining an 'informal_protocol' object.\n");
static PyType_Slot sel_slots[] = {
    {.slot = Py_tp_dealloc, .pfunc = (void*)&sel_dealloc},
    {.slot = Py_tp_getattro, .pfunc = (void*)&PyObject_GenericGetAttr},
    {.slot = Py_tp_doc, .pfunc = (void*)&base_selector_type_doc},
    {.slot = Py_tp_new, .pfunc = (void*)&pysel_new},

    {0, NULL} /* sentinel */
};

static PyType_Spec sel_spec = {
    .name      = "objc.selector",
    .basicsize = sizeof(PyObjCBaseSelector),
    .itemsize  = 0,
    .flags     = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HEAPTYPE | Py_TPFLAGS_IMMUTABLETYPE
                 | Py_TPFLAGS_BASETYPE,
    .slots     = sel_slots,
};

/*
 * Selector type for 'native' selectors (that is, selectors that are not
 * implemented as python methods)
 */
static PyObject*
objcsel_repr(PyObject* _self)
{
    PyObjCNativeSelector* sel = (PyObjCNativeSelector*)_self;
    return PyUnicode_FromFormat(
        "<unbound native-selector %s in %s%s>", sel_getName(sel->base.sel_selector),
        class_isMetaClass(sel->base.sel_class) ? "metaclass " : "",
        class_getName(sel->base.sel_class));
}

static Py_hash_t
objcsel_hash(PyObject* o)
{
    PyObjCNativeSelector* self    = (PyObjCNativeSelector*)o;
    Py_hash_t             h       = 0;
    const char*           selname = sel_getName(self->base.sel_selector);

    h ^= (long)(self->base.sel_class);
#if PY_VERSION_HEX >= 0x030e0000
    h ^= Py_HashBuffer(selname, strlen(selname));
#else
    PyHash_FuncDef* hashfunc = PyHash_GetFuncDef();
    h ^= hashfunc->hash(selname, strlen(selname));
#endif

    return h;
}

static PyObject*
objcsel_richcompare(PyObject* a, PyObject* b, int op)
{
    if (op == Py_EQ || op == Py_NE) {
        if (PyObjCNativeSelector_Check(a) && PyObjCNativeSelector_Check(b)) {

            PyObjCNativeSelector* sel_a = (PyObjCNativeSelector*)a;
            PyObjCNativeSelector* sel_b = (PyObjCNativeSelector*)b;
            int                   same  = 1;

            if (sel_a->base.sel_selector != sel_b->base.sel_selector) {
                same = 0;
            }
            if (sel_a->base.sel_class != sel_b->base.sel_class) {
                same = 0;
            }
            if ((op == Py_EQ && !same) || (op == Py_NE && same)) {
                Py_RETURN_FALSE;
            } else {
                Py_RETURN_TRUE;
            }

        } else {
            if (op == Py_EQ) {
                Py_RETURN_FALSE;

            } else {
                Py_RETURN_TRUE;
            }
        }

    } else {
        if (PyObjCSelector_Check(a) && PyObjCSelector_Check(b)) {
            SEL sel_a = PyObjCSelector_GetSelector(a);
            SEL sel_b = PyObjCSelector_GetSelector(b);

            int r = strcmp(sel_getName(sel_a), sel_getName(sel_b));
            switch (op) { // LCOV_BR_EXCL_LINE
            case Py_LT:
                if (r < 0) {
                    Py_RETURN_TRUE;
                } else {
                    Py_RETURN_FALSE;
                };
            case Py_LE:
                if (r <= 0) {
                    Py_RETURN_TRUE;
                } else {
                    Py_RETURN_FALSE;
                };
            case Py_GT:
                if (r > 0) {
                    Py_RETURN_TRUE;
                } else {
                    Py_RETURN_FALSE;
                };
            case Py_GE:
                if (r >= 0) {
                    Py_RETURN_TRUE;
                } else {
                    Py_RETURN_FALSE;
                };
            } // LCOV_EXCL_LINE
        }

        Py_RETURN_NOTIMPLEMENTED;
    }
}

static void
objcsel_dealloc(PyObject* obj)
{
    if (((PyObjCNativeSelector*)obj)->sel_cif != NULL) { // LCOV_BR_EXCL_LINE
        /* XXX: Native selectors are cached on the class and hence
         *      not deallocated once actually called.
         */
        // LCOV_EXCL_START
        PyObjCFFI_FreeCIF(((PyObjCNativeSelector*)obj)->sel_cif);
        // LCOV_EXCL_STOP
    } // LCOV_EXCL_LINE
    sel_dealloc(obj);
}

static PyObject* _Nullable objcsel_vectorcall_simple(
    PyObject* _self, PyObject* _Nonnull const* _Nonnull args, size_t nargsf,
    PyObject* _Nullable kwnames)
{
    PyObjCNativeSelector* self = (PyObjCNativeSelector*)_self;

    if (PyObjC_CheckNoKwnames(_self, kwnames) == -1) {
        return NULL;
    }
    if (PyVectorcall_NARGS(nargsf) < 1) {
        PyErr_SetString(PyExc_TypeError, "Missing argument: self");
        return NULL;
    }

    PyObjCMethodSignature* methinfo = PyObjCSelector_GetMetadata(_self);
    if (unlikely(methinfo == NULL)) { // LCOV_BR_EXCL_LINE
        return NULL;                  // LCOV_EXCL_LINE
    }

    if (version_is_deprecated(methinfo->deprecated)) {
        char  buf[128];
        Class cls = PyObjCSelector_GetClass(_self);
        SEL   sel = PyObjCSelector_GetSelector(_self);

        snprintf(buf, 128, "%c[%s %s] is a deprecated API (macOS %d.%d)",
                 PyObjCSelector_IsClassMethod(_self) ? '+' : '-', class_getName(cls),
                 sel_getName(sel), methinfo->deprecated / 100,
                 methinfo->deprecated % 100);
        if (PyErr_Warn(PyObjCExc_DeprecationWarning, buf) < 0) {
            Py_CLEAR(methinfo);
            return NULL;
        }
    }
    Py_CLEAR(methinfo);

    if (sel_validate_self(&(self->base), args[0]) < 0) {
        Py_CLEAR(methinfo);
        return NULL;
    }
    if (PyObjCSelector_IsClassMethod(_self) && PyObjCMetaClass_Check(args[0])
        && PyObject_IsSubclass(args[0], (PyObject*)&PyObjCMetaClass_Type)) {
        PyObject* tmp = PyObjCClass_ClassForMetaClass(args[0]);
        if (unlikely(tmp == NULL)) { // LCOV_BR_EXCL_LINE
            // LCOV_EXCL_START
            PyErr_SetString(PyObjCExc_InternalError, "Cannot find class for metaclass");
            return NULL;
            // LCOV_EXCL_STOP
        }
        PyObject* res = PyObjCFFI_Caller_SimpleSEL((PyObject*)self, tmp, args + 1,
                                                   PyVectorcall_NARGS(nargsf) - 1);
        Py_CLEAR(tmp);
        return res;
    }
    return PyObjCFFI_Caller_SimpleSEL((PyObject*)self, args[0], args + 1,
                                      PyVectorcall_NARGS(nargsf) - 1);
}

PyObjC_CallFunc _Nullable PyObjCSelector_GetCallFunc(PyObjCNativeSelector*  obj,
                                                     PyObjCMethodSignature* methinfo)
{
    assert(PyObjCNativeSelector_Check(obj));
    if (obj->sel_call_func != NULL) {
        return obj->sel_call_func;
    } else {
        assert(obj->base.sel_class != NULL);
        assert(methinfo != NULL);

        PyObjC_CallFunc execute = PyObjC_FindCallFunc(
            obj->base.sel_class, obj->base.sel_selector, methinfo->signature);
        if (execute == NULL) {
            return NULL;
        }

        obj->sel_call_func = execute;
        /* Update the vectorcall slot when a faster call is possible */
        if (obj->base.sel_methinfo->shortcut_signature && execute == PyObjCFFI_Caller) {
            obj->base.sel_vectorcall = objcsel_vectorcall_simple;
        }

        return execute;
    }
}

static PyObject* _Nullable objcsel_vectorcall(PyObject* _self,
                                              PyObject* _Nonnull const* _Nonnull args,
                                              size_t nargsf, PyObject* _Nullable kwnames)
{
    /* XXX: Need logic to reset sel_call_func and sel_vectocall when
     * the methodinfo changes, both here and in the "simple" variant.
     * This way extensions can register a new call_func even after the
     * method has been resolved.
     */

    PyObjCNativeSelector* self    = (PyObjCNativeSelector*)_self;
    PyObjC_CallFunc       execute = NULL;

    if (PyObjC_CheckNoKwnames(_self, kwnames) == -1) {
        return NULL;
    }

    /* XXX: Fold this into execution of callfunc, that also checks for bound/unbound
     */
    if (PyVectorcall_NARGS(nargsf) < 1) {
        PyErr_SetString(PyExc_TypeError, "Missing argument: self");
        return NULL;
    }

    PyObjCMethodSignature* methinfo = PyObjCSelector_GetMetadata(_self);
    if (unlikely(methinfo == NULL)) { // LCOV_BR_EXCL_LINE
        return NULL;                  // LCOV_EXCL_LINE
    }

    if (version_is_deprecated(methinfo->deprecated)) {
        char  buf[128];
        Class cls = PyObjCSelector_GetClass(_self);
        SEL   sel = PyObjCSelector_GetSelector(_self);

        assert(cls);
        assert(sel);

        snprintf(buf, 128, "%c[%s %s] is a deprecated API (macOS %d.%d)",
                 PyObjCSelector_IsClassMethod(_self) ? '+' : '-', class_getName(cls),
                 sel_getName(sel), methinfo->deprecated / 100,
                 methinfo->deprecated % 100);
        if (PyErr_Warn(PyObjCExc_DeprecationWarning, buf) < 0) {
            Py_CLEAR(methinfo);
            return NULL;
        }
    }

    execute = PyObjCSelector_GetCallFunc(self, methinfo);
    Py_CLEAR(methinfo);
    if (execute == NULL) {
        return NULL;
    }

    if (sel_validate_self(&(self->base), args[0]) < 0) {
        return NULL;
    }
    if (PyObjCSelector_IsClassMethod(_self) && PyObjCMetaClass_Check(args[0])
        && PyObject_IsSubclass(args[0], (PyObject*)&PyObjCMetaClass_Type)) {
        PyObject* tmp = PyObjCClass_ClassForMetaClass(args[0]);
        if (unlikely(tmp == NULL)) { // LCOV_BR_EXCL_LINE
            // LCOV_EXCL_START
            PyErr_SetString(PyObjCExc_InternalError, "Cannot find class for metaclass");
            return NULL;
            // LCOV_EXCL_STOP
        }
        PyObject* res =
            execute((PyObject*)self, tmp, args + 1, PyVectorcall_NARGS(nargsf) - 1);
        Py_CLEAR(tmp);
        return res;
    }
    return execute((PyObject*)self, args[0], args + 1, PyVectorcall_NARGS(nargsf) - 1);
}

static PyObject* _Nullable objcsel_new(PyTypeObject* type,
                                       PyObject* _Nullable args
                                       __attribute__((__unused__)),
                                       PyObject* _Nullable kwds
                                       __attribute__((__unused__)))
{
    return PyErr_Format(PyExc_TypeError, "Cannot create instances of %s", type->tp_name);
}

static PyGetSetDef objcsel_getset[] = {{
                                           .name = "__doc__",
                                           .get  = PyObjC_GetCallableDocString,
                                           .doc  = "The document string for a method",
                                       },
                                       {
                                           .name = "__signature__",
                                           .get  = PyObjC_GetCallableSignature,
                                           .doc  = "inspect.Signature for a method",
                                       },
                                       {
                                           .name = "isHidden",
                                           .get  = base_hidden,
                                           .set  = base_hidden_setter,
                                           .doc  = base_hidden_doc,
                                       },
                                       {
                                           .name = "isRequired",
                                           .get  = base_required,
                                           .doc  = base_required_doc,
                                       },
                                       {
                                           .name = "isClassMethod",
                                           .get  = base_class_method,
                                           .doc  = base_class_method_doc,
                                       },
                                       {
                                           .name = "definingClass",
                                           .get  = base_class,
                                           .doc  = base_class_doc,
                                       },
                                       {
                                           .name = "__objclass__",
                                           .get  = base_class,
                                           .doc  = base_class_doc,
                                       },
                                       {
                                           .name = "signature",
                                           .get  = base_signature,
                                           .set  = base_signature_setter,
                                           .doc  = base_signature_doc,
                                       },
                                       {
                                           .name = "native_signature",
                                           .get  = base_native_signature,
                                           .doc  = base_native_signature_doc,
                                       },
                                       {
                                           .name = "self",
                                           .get  = base_self,
                                           .doc  = base_self_doc,
                                       },
                                       {
                                           .name = "selector",
                                           .get  = base_selector,
                                           .doc  = base_selector_doc,
                                       },
                                       {
                                           .name = "__name__",
                                           .get  = base_name,
                                           .doc  = base_name_doc,
                                       },
                                       {
                                           .name = NULL /* SENTINEL */
                                       }};

static PyMemberDef objcsel_members[] = {
    {
        .name   = "__vectorcalloffset__",
        .type   = T_PYSSIZET,
        .offset = offsetof(PyObjCNativeSelector, base.sel_vectorcall),
        .flags  = READONLY,
    },
    {
        .name = NULL /* SENTINEL */
    }};

static PyType_Slot objcsel_slots[] = {
    {.slot = Py_tp_dealloc, .pfunc = (void*)&objcsel_dealloc},
    {.slot = Py_tp_repr, .pfunc = (void*)&objcsel_repr},
    {.slot = Py_tp_getattro, .pfunc = (void*)&PyObject_GenericGetAttr},
    {.slot = Py_tp_richcompare, .pfunc = (void*)&objcsel_richcompare},
    {.slot = Py_tp_getset, .pfunc = (void*)&objcsel_getset},
    {.slot = Py_tp_descr_get, .pfunc = (void*)&base_descr_get},
    {.slot = Py_tp_methods, .pfunc = (void*)&base_methods},
    {.slot = Py_tp_members, .pfunc = (void*)&objcsel_members},
    {.slot = Py_tp_call, .pfunc = (void*)&PyVectorcall_Call},
    {.slot = Py_tp_hash, .pfunc = (void*)&objcsel_hash},
    {.slot = Py_tp_new, .pfunc = (void*)&objcsel_new},

    {0, NULL} /* sentinel */
};

static PyType_Spec objcsel_spec = {
    .name      = "objc.native_selector",
    .basicsize = sizeof(PyObjCNativeSelector),
    .itemsize  = 0,
    .flags     = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HEAPTYPE | Py_TPFLAGS_IMMUTABLETYPE
                 | Py_TPFLAGS_HAVE_VECTORCALL | Py_TPFLAGS_METHOD_DESCRIPTOR,

    .slots = objcsel_slots,
};

PyObject*
PyObjCSelector_FindNative(PyObject* self, const char* name)
{
    SEL       sel = PyObjCSelector_DefaultSelector(name);
    PyObject* retval;

    NSMethodSignature* methsig;
    char               buf[2048];

    if (PyObjCObject_Check(self)) {
        PyObject* hidden = PyObjCClass_HiddenSelector((PyObject*)Py_TYPE(self), sel, NO);
        if (unlikely(hidden == NULL && PyErr_Occurred())) { // LCOV_BR_EXCL_LINE
            return NULL;                                    // LCOV_EXCL_LINE
        }
        if (PyObjCObject_IsMagic(self) || hidden) {
            Py_CLEAR(hidden);
            PyErr_Format(PyExc_AttributeError, "No attribute %s", name);
            return NULL;
        }
        Py_CLEAR(hidden);

    } else {
        PyObject* hidden;
        hidden = PyObjCClass_HiddenSelector(self, sel, YES);

        if (hidden) {
            Py_CLEAR(hidden);
            PyErr_Format(PyExc_AttributeError, "No attribute %s", name);
            return NULL;
        } else if (unlikely(PyErr_Occurred())) { // LCOV_BR_EXCL_LINE
            return NULL;                         // LCOV_EXCL_LINE
        }
    }

    if (name[0] == '_' && name[1] == '_') {
        /* No known Objective-C class has methods whose name
         * starts with '__' or '_:'. This allows us to shortcut
         * lookups for special names, which speeds up tools like
         * pydoc.
         */
        PyErr_Format(PyExc_AttributeError, "No attribute %s", name);
        return NULL;
    }

    if (unlikely(PyObjCClass_Check(self))) {
        Class cls = PyObjCClass_GetClass(self);

        if (!cls) {
            PyErr_Format(PyExc_AttributeError, "No attribute %s", name);
            return NULL;
        }

        /* XXX: Class doesn't exist in modern versions of macOS, check
         * when it was removed.
         */
        if (unlikely(strcmp(class_getName(cls), "_NSZombie") == 0 // LCOV_BR_EXCL_LINE
                     || strcmp(class_getName(cls), "_CNZombie_")
                            == 0)) { // LCOV_BR_EXCL_LINE
            // LCOV_EXCL_START
            PyErr_Format(PyExc_AttributeError, "No attribute %s", name);
            return NULL;
            // LCOV_EXCL_STOP
        }

        if (strcmp(class_getName(cls), "NSProxy") == 0) {
            if (unlikely(sel ==
                         @selector(methodSignatureForSelector:))) { // LCOV_BR_EXCL_LINE
                // LCOV_EXCL_START
                PyErr_Format(PyExc_AttributeError, "Accessing %s.%s is not supported",
                             class_getName(cls), name);
                return NULL;
                // LCOV_EXCL_STOP
            }
        }

        @try {
            if ((class_getClassMethod(cls, @selector(respondsToSelector:)) != NULL) &&
                [cls respondsToSelector:sel]) {
                methsig = [cls methodSignatureForSelector:sel];

                const char* typestr =
                    PyObjC_NSMethodSignatureToTypeString(methsig, buf, sizeof(buf));
                if (unlikely(typestr == NULL)) { // LCOV_BR_EXCL_LINE
                    return NULL;                 // LCOV_EXCL_LINE
                }
                retval = PyObjCSelector_NewNative(cls, sel, typestr, 1);
            } else {
                PyErr_Format(PyExc_AttributeError, "No attribute %s", name);
                retval = NULL;
            }

        } @catch (NSObject* localException) {
            PyObjCErr_FromObjC(localException);
            PyErr_Format(PyExc_AttributeError, "No attribute %s", name);
            retval = NULL;
        }

        return retval;

    } else if (likely(PyObjCObject_Check(self))) { // LCOV_BR_EXCL_LINE
        id object;

        object = PyObjCObject_GetObject(self);

        @try {
            if (nil != (methsig = [object methodSignatureForSelector:sel])) {
                PyObjCNativeSelector* res;
                const char*           typestr =
                    PyObjC_NSMethodSignatureToTypeString(methsig, buf, sizeof(buf));
                if (typestr == NULL) { // LCOV_BR_EXCL_LINE
                    retval = NULL;     // LCOV_EXCL_LINE
                } else {               // LCOV_EXCL_LINE
                    res = (PyObjCNativeSelector*)PyObjCSelector_NewNative(
                        (Class _Nonnull)object_getClass(object), sel, typestr, 0);
                    if (likely(res != NULL)) { // LCOV_BR_EXCL_LINE
                        /* Bind the method to self */
                        retval = PyObjCBoundSelector_New(self, (PyObjCSelector*)res);
                        Py_CLEAR(res);
                    } else {
                        retval = NULL; // LCOV_EXCL_LINE
                    }
                }
            } else {
                PyErr_Format(PyExc_AttributeError, "No attribute %s", name);
                retval = NULL;
            }

            // LCOV_EXCL_START
        } @catch (NSObject* localException) {
            PyErr_Format(PyExc_AttributeError, "No attribute %s", name);
            retval = NULL;
        }
        // LCOV_EXCL_STOP

        return retval;

    } else {
        // LCOV_EXCL_START
        PyErr_SetString(PyExc_RuntimeError, "PyObjCSelector_FindNative called on plain "
                                            "python object");
        return NULL;
        // LCOV_EXCL_STOP
    }
}

PyObject*
PyObjCSelector_NewNative(Class class, SEL selector, const char* signature,
                         int class_method)
{
    PyObjCNativeSelector* result;
    const char*           native_signature = signature;

    assert(signature != NULL);

    result = PyObject_New(PyObjCNativeSelector, (PyTypeObject*)PyObjCNativeSelector_Type);
    if (unlikely(result == NULL)) // LCOV_BR_EXCL_LINE
        return NULL;              // LCOV_EXCL_LINE

    result->base.sel_class            = class;
    result->base.sel_flags            = 0;
    result->base.sel_mappingcount     = 0;
    result->base.sel_methinfo         = NULL;
    result->base.sel_vectorcall       = objcsel_vectorcall;
    result->sel_call_func             = NULL;
    result->sel_cif                   = NULL;
    result->base.sel_python_signature = (const char* _Nonnull)NULL;
    result->base.sel_native_signature = (const char* _Nonnull)NULL;

    result->base.sel_selector = selector;

    Py_ssize_t len = strlen(signature) + 1;
    char*      tmp = PyMem_Malloc(len);
    if (unlikely(tmp == NULL)) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        Py_DECREF(result);
        PyErr_NoMemory();
        return NULL;
        // LCOV_EXCL_STOP
    }
    if (PyObjCRT_SimplifySignature(signature, tmp, len) == -1) {
        /* In some cases the runtime contains signatures that
         * PyObjC cannot parse. Copy those as-is for easier introspection.
         */
        PyErr_Clear();
        strlcpy(tmp, signature, len);
    }

    result->base.sel_python_signature = tmp;
    result->base.sel_native_signature = PyObjCUtil_Strdup(native_signature);
    if (unlikely( // LCOV_BR_EXCL_LINE
            result->base.sel_native_signature == NULL)) {
        // LCOV_EXCL_START
        Py_DECREF(result);
        return NULL;
        // LCOV_EXCL_STOP
    }

    if (class_method) {
        result->base.sel_flags |= PyObjCSelector_kCLASS_METHOD;
    }

    PyObjCMethodSignature* methinfo = PyObjCSelector_GetMetadata((PyObject*)result);
    if (unlikely(methinfo == NULL)) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        Py_DECREF(result);
        return NULL;
        // LCOV_EXCL_STOP
    }
    Py_CLEAR(methinfo);
    return (PyObject*)result;
}

static char gSheetMethodSignature[] = {_C_VOID, _C_ID,  _C_SEL,  _C_ID,
                                       _C_INT,  _C_PTR, _C_VOID, 0};

/* XXX: Reorder code to take away need for forward declaration */
static PyObject* _Nullable pysel_vectorcall(PyObject* _self,
                                            PyObject* _Nonnull const* _Nonnull args,
                                            size_t nargsf, PyObject* _Nullable kwnames);

PyObject*
PyObjCSelector_New(PyObject* callable, SEL selector, const char* _Nullable signature,
                   int class_method, Class _Nullable cls)
{
    PyObjCPythonSelector* result;

    /*
     * XXX: Investigate using the python helper in objc._transform instead of
     *      replicating part of the logic here.
     */
    if (signature == NULL && PyObjCPythonSelector_Check(callable)) {
        signature = PyObjCUtil_Strdup(
            ((PyObjCPythonSelector*)callable)->base.sel_python_signature);

    } else if (signature == NULL) {
        const char* selname = sel_getName(selector);
        size_t      len     = strlen(selname);
        if (len > 30
            && strcmp(selname + len - 30, "DidEnd:returnCode:contextInfo:") == 0) {
            /* XXX: This is a bit too magic...
             *      Consider moving this logic to a python helper.
             */
            signature = PyObjCUtil_Strdup(gSheetMethodSignature);
        } else {
            signature = pysel_default_signature(selector, callable);
        }
    } else {
        signature = PyObjCUtil_Strdup(signature);
    }
    if (unlikely(signature == NULL)) // LCOV_BR_EXCL_LINE
        return NULL;                 // LCOV_EXCL_LINE

    result = PyObject_New(PyObjCPythonSelector, (PyTypeObject*)PyObjCPythonSelector_Type);
    if (unlikely(result == NULL)) // LCOV_BR_EXCL_LINE
        return NULL;              // LCOV_EXCL_LINE
    result->base.sel_class = cls;
    result->base.sel_flags = 0;
    result->base.sel_methinfo =
        (PyObjCMethodSignature* _Nonnull)NULL; /* We might not know the class right now */
    result->callable = (PyObject* _Nonnull)NULL;
    result->argcount = 0;

    result->base.sel_selector         = selector;
    result->base.sel_python_signature = signature;
    char* tmp                         = PyObjCUtil_Strdup(signature);
    if (unlikely(tmp == NULL)) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        Py_DECREF(result);
        return NULL;
        // LCOV_EXCL_STOP
    }
    result->base.sel_native_signature = tmp;
    result->base.sel_vectorcall       = pysel_vectorcall;

    if (unlikely(PyObjC_RemoveInternalTypeCodes((char*)result->base.sel_native_signature)
                 == -1)) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        Py_DECREF(result);
        return NULL;
        // LCOV_EXCL_STOP
    }

    if (PyObjC_is_pyfunction(callable)) {
        result->argcount = PyObjC_num_arguments(callable);
        if (result->argcount == -1) {
            Py_DECREF(result);
            return NULL;
        }

    } else if (PyMethod_Check(callable)) {
        assert(PyMethod_Self(callable) != NULL);
        result->argcount = PyObjC_num_arguments(callable) - 1;
        if (unlikely(result->argcount == -2)) { // LCOV_BR_EXCL_LINE
            /* 'PyObjC_num_arguments' can only fail if 'callable'
             * is not a valid function, and we already checked that.
             */
            // LCOV_EXCL_START
            Py_DECREF(result);
            return NULL;
            // LCOV_EXCL_STOP
        }

    } else if (PyObjC_is_pymethod(callable)) {
        result->argcount = PyObjC_num_arguments(callable) - 1;
        if (unlikely(result->argcount == -2)) { // LCOV_BR_EXCL_LINE
            /* 'PyObjC_num_arguments' can only fail if 'callable'
             * is not a valid method, and we already checked that.
             */
            // LCOV_EXCL_START
            Py_DECREF(result);
            return NULL;
            // LCOV_EXCL_STOP
        }

    } else if (callable == Py_None) {
        result->argcount = 0;

    } else {
        result->argcount = 0;
        const char* s    = sel_getName(selector);
        while ((s = strchr(s, ':')) != NULL) {
            result->argcount++;
            s++;
        }
    }

    if (class_method) {
        result->base.sel_flags |= PyObjCSelector_kCLASS_METHOD;
    }

    result->callable = callable;
    Py_INCREF(result->callable);

    return (PyObject*)result;
}

/*
 * Selector type for python selectors (that is, selectors that are
 * implemented as python methods)
 *
 * This one can be allocated from python code.
 */

static Py_hash_t
pysel_hash(PyObject* o)
{
    PyObjCPythonSelector* self = (PyObjCPythonSelector*)o;
    Py_hash_t             h    = 0;

    h ^= (long)(self->base.sel_class);
    h ^= PyObject_Hash(self->callable);

    return h;
}

static PyObject* _Nullable pysel_richcompare(PyObject* a, PyObject* b, int op)
{
    if (op == Py_EQ || op == Py_NE) {
        if (PyObjCPythonSelector_Check(a) && PyObjCPythonSelector_Check(b)) {
            PyObjCPythonSelector* sel_a = (PyObjCPythonSelector*)a;
            PyObjCPythonSelector* sel_b = (PyObjCPythonSelector*)b;
            int                   same  = 1;
            int                   r;

            if (sel_a->base.sel_selector != sel_b->base.sel_selector) {
                same = 0;
            }
            if (sel_a->base.sel_class != sel_b->base.sel_class) {
                same = 0;
            }
            r = PyObject_RichCompareBool(sel_a->callable, sel_b->callable, Py_EQ);
            if (r == -1) {
                return NULL;
            }
            if (!r) {
                same = 0;
            }

            if ((op == Py_EQ && !same) || (op == Py_NE && same)) {
                Py_RETURN_FALSE;
            } else {
                Py_RETURN_TRUE;
            }

        } else {
            if (op == Py_EQ) {
                Py_RETURN_FALSE;
            } else {
                Py_RETURN_TRUE;
            }
        }
    } else {
        if (PyObjCSelector_Check(a) && PyObjCSelector_Check(b)) {
            SEL sel_a = PyObjCSelector_GetSelector(a);
            SEL sel_b = PyObjCSelector_GetSelector(b);

            int r = strcmp(sel_getName(sel_a), sel_getName(sel_b));
            switch (op) {
            case Py_LT:
                if (r < 0) {
                    Py_RETURN_TRUE;
                } else {
                    Py_RETURN_FALSE;
                };
            case Py_LE:
                if (r <= 0) {
                    Py_RETURN_TRUE;
                } else {
                    Py_RETURN_FALSE;
                };
            case Py_GT:
                if (r > 0) {
                    Py_RETURN_TRUE;
                } else {
                    Py_RETURN_FALSE;
                };
            case Py_GE:
                if (r >= 0) {
                    Py_RETURN_TRUE;
                } else {
                    Py_RETURN_FALSE;
                };
            }
        }
        Py_RETURN_NOTIMPLEMENTED;
    }
}

static PyObject*
pysel_repr(PyObject* _self)
{
    PyObjCPythonSelector* sel = (PyObjCPythonSelector*)_self;

    if (sel->base.sel_class) {
        return PyUnicode_FromFormat("<unbound selector %s of %s at %p>",
                                    sel_getName(sel->base.sel_selector),
                                    class_getName(sel->base.sel_class), sel);

    } else {
        return PyUnicode_FromFormat("<unbound selector %s at %p>",
                                    sel_getName(sel->base.sel_selector), sel);
    }
}

static PyObject* _Nullable pysel_vectorcall(PyObject* _self,
                                            PyObject* _Nonnull const* _Nonnull args,
                                            size_t nargsf, PyObject* _Nullable kwnames)
{
    PyObjCPythonSelector* self = (PyObjCPythonSelector*)_self;

    if (self->callable == NULL || self->callable == Py_None) {
        PyErr_Format(PyExc_TypeError, "Calling abstract methods with selector '%s'",
                     sel_getName(self->base.sel_selector));
        return NULL;
    }

    if (!PyObjC_is_pymethod(self->callable)) {
        if (PyVectorcall_NARGS(nargsf) < 1) {
            PyErr_SetString(PyExc_TypeError, "need self argument");
            return NULL;
        }

        /* normal function code will perform other checks */
    }

    /*
     * Assume callable will check arguments
     */
    return PyObject_Vectorcall(self->callable, args, nargsf, kwnames);
}

static char*
pysel_default_signature(SEL selector, PyObject* callable)
{
    Py_ssize_t  arg_count;
    char*       result;
    const char* selname = sel_getName(selector);

    if (unlikely(selname == NULL)) { // LCOV_BR_EXCL_LINE
        /* XXX: replace by assert */
        // LCOV_EXCL_START
        PyErr_SetString(PyExc_ValueError, "Cannot extract string from selector");
        return NULL;
        // LCOV_EXCL_STOP
    }

    arg_count = 0;

    selname = strchr(selname, ':');
    while (selname) {
        arg_count++;
        selname = strchr(selname + 1, ':');
    }

    /* arguments + return-type + selector */
    result = PyMem_Malloc(arg_count + 4);
    if (unlikely(result == 0)) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        PyErr_NoMemory();
        return NULL;
        // LCOV_EXCL_STOP
    }

    /* We want: v@:@... (final sequence of arg_count-1 @-chars) */
    memset(result, _C_ID, arg_count + 3);
    result[2]             = _C_SEL;
    result[arg_count + 3] = '\0';

    if (!PyObjC_returns_value(callable)) {
        result[0] = _C_VOID;
        if (unlikely(PyErr_Occurred())) { // LCOV_BR_EXCL_LINE
            // XXX: This cannot fail in practice
            // LCOV_EXCL_START
            PyMem_Free(result);
            return NULL;
            // LCOV_EXCL_STOP
        }
    }

    return result;
}

/*
 * XXX: This logic is different from the function below.
 */
static SEL _Nullable pysel_default_selector(PyObject* callable)
{
    char      buf[1024];
    char*     cur;
    PyObject* name = PyObject_GetAttrString(callable, "__name__");

    if (name == NULL)
        return NULL;

    if (PyUnicode_Check(name)) {
        PyObject* bytes = PyUnicode_AsEncodedString(name, NULL, NULL);
        if (bytes == NULL) {
            return NULL;
        }
        strncpy(buf, PyBytes_AS_STRING(bytes), sizeof(buf) - 1);
        Py_DECREF(bytes);

    } else {
        /* The name of built-in callables is always a unicode string */
        PyErr_Format(PyExc_TypeError, "%R: __name__ is not a string", callable);
        return NULL;
    }

    if (buf[strlen(buf) - 1] != '_') {
        /* Method name doesn't end with an underscore,
         * the default selector cannot be a multi-segment
         * one. Hence don't try to translate.
         */
        return sel_registerName(buf);
    }

    cur = strchr(buf, '_');
    while (cur != NULL) {
        *cur = ':';
        cur  = strchr(cur, '_');
    }
    return sel_registerName(buf);
}

SEL
PyObjCSelector_DefaultSelector(const char* methname)
{
    char       buf[1024];
    char*      cur;
    Py_ssize_t ln;

    strncpy(buf, methname, sizeof(buf) - 1);
    ln = strlen(buf);

    cur = buf + ln;
    if (cur - buf > 3) {
        if (cur[-1] != '_') {
            return sel_registerName(buf);
        }

        if (cur[-1] == '_' && cur[-2] == '_') {
            cur[-2] = '\0';
            if (PyObjC_IsPythonKeyword(buf)) {
                return sel_registerName(buf);
            }
            cur[-2] = '_';
        }
    }

    /* Skip leading underscores, '_doFoo_' is probably '_doFoo:' in
     * Objective-C, not ':doFoo:'.
     *
     * Also if the name starts and ends with two underscores, return
     * it unmodified. This avoids mangling of Python's special methods.
     *
     * Also don't rewrite two underscores between name elements, such
     * as '__pyobjc__setItem_' -> '__pyobjc__setitem:'
     *
     * Also: when the name starts with two capital letters and an underscore
     * don't replace the underscore, the 'XX_' prefix is a common way to
     * namespace selectors.
     *
     * Both are heuristics and could be the wrong choice, but either
     * form is very unlikely to exist in ObjC code.
     */
    cur = buf;

    if (ln > 5) {
        if (cur[0] == '_' && cur[1] == '_' && cur[ln - 1] == '_' && cur[ln - 2] == '_') {
            return sel_registerName(buf);
        }
    }

    while (*cur == '_') {
        cur++;
    }

    if (isupper(cur[0]) && isupper(cur[1]) && cur[2] == '_') {
        cur += 3;
    }

    /* Replace all other underscores by colons */
    cur = strchr(cur, '_');
    while (cur != NULL) {
        if (cur[1] == '_' && cur[2] && cur[2] != '_' && cur[-1] != '_') {
            /* Don't translate double underscores between
             * name elements.
             *
             * NOTE: cur[-1] is save because we've skipped leading
             * underscores earlier in this function.
             */
            cur += 2;
        } else {
            *cur = ':';
        }
        cur = strchr(cur, '_');
    }
    return sel_registerName(buf);
}

static PyObject* _Nullable pysel_new(PyTypeObject* type __attribute__((__unused__)),
                                     PyObject* _Nullable args, PyObject* _Nullable kwds)
{
    static char* keywords[] = {"function",   "selector", "signature", "isClassMethod",
                               "isRequired", "isHidden", NULL};
    PyObjCPythonSelector* result;
    PyObject*             callable;
    char*                 signature = NULL;
    char*                 selector  = NULL;
    SEL                   objc_selector;
    int                   class_method = 0;
    int                   required     = 1;
    int                   hidden       = 0;

    if (!PyArg_ParseTupleAndKeywords(args, kwds, "O|yyiii", keywords, &callable,
                                     &selector, &signature, &class_method, &required,
                                     &hidden)) {
        return NULL;
    }

    if (signature != NULL) {
        /* Check if the signature string is valid */
        const char* cur;

        cur = signature;
        while (*cur != '\0') {
            cur = PyObjCRT_SkipTypeSpec(cur);
            if (cur == NULL) {
                PyErr_SetString(PyExc_ValueError, "invalid signature");
                return NULL;
            }
        }
    }

    if (callable != Py_None && !PyCallable_Check(callable)
        && !PyObject_TypeCheck(callable, &PyClassMethod_Type)) {
        PyErr_SetString(PyExc_TypeError, "argument 'method' must be callable");
        return NULL;
    }

    if (PyObject_TypeCheck(callable, &PyStaticMethod_Type)) {
        PyErr_SetString(PyExc_TypeError, "cannot use staticmethod as the "
                                         "callable for a selector.");
        return NULL;
    }

    if (PyObject_TypeCheck(callable, &PyClassMethod_Type)) {
        /* Special treatment for 'classmethod' instances */
        PyObject* tmp =
            PyObject_CallMethod(callable, "__get__", "OO", Py_None, &PyList_Type);
        if (unlikely(tmp == NULL)) { // LCOV_BR_EXCL_LINE
            return NULL;             // LCOV_EXCL_LINE
        }

        callable = PyObject_GetAttrString(tmp, "__func__");
        Py_DECREF(tmp);
        if (unlikely(callable == NULL)) { // LCOV_BR_EXCL_LINE
            return NULL;                  // LCOV_EXCL_LINE
        }
        class_method = 1;

    } else {
        Py_INCREF(callable);
    }

    if (selector == NULL) {
        objc_selector = pysel_default_selector(callable);
        if (objc_selector == NULL) {
            return NULL;
        }
    } else {
        objc_selector = sel_registerName(selector);
    }

    result = (PyObjCPythonSelector*)PyObjCSelector_New(callable, objc_selector, signature,
                                                       class_method, nil);
    Py_DECREF(callable);
    if (!result) {
        return NULL;
    }

    if (required) {
        result->base.sel_flags |= PyObjCSelector_kREQUIRED;
    }

    if (hidden) {
        result->base.sel_flags |= PyObjCSelector_kHIDDEN;
    }
    return (PyObject*)result;
}

static void
pysel_dealloc(PyObject* obj)
{
    if (((PyObjCPythonSelector*)obj)->callable != NULL) {
        /* This open codes Py_CLEAR to avoid a nullabity warning */
        PyObject* tmp                          = ((PyObjCPythonSelector*)obj)->callable;
        ((PyObjCPythonSelector*)obj)->callable = (PyObject* _Nonnull)NULL;
        Py_DECREF(tmp);
    }
    sel_dealloc(obj);
}

PyDoc_STRVAR(pysel_get_callable_doc,
             "Returns the python 'function' that implements this method.\n"
             "\n");
static PyObject*
pysel_get_callable(PyObject* _self, void* _Nullable closure __attribute__((__unused__)))
{
    PyObjCPythonSelector* self = (PyObjCPythonSelector*)_self;
    Py_INCREF(self->callable);
    return self->callable;
}

PyDoc_STRVAR(pysel_docstring_doc, "The document string for a method");
static PyObject* _Nullable pysel_docstring(PyObject* _self, void* _Nullable closure
                                           __attribute__((__unused__)))
{
    PyObjCPythonSelector* self = (PyObjCPythonSelector*)_self;

    return PyObject_GetAttrString(self->callable, "__doc__");
}

static PyGetSetDef pysel_getset[] = {{
                                         .name = "callable",
                                         .get  = pysel_get_callable,
                                         .doc  = pysel_get_callable_doc,
                                     },
                                     {
                                         .name = "__doc__",
                                         .get  = pysel_docstring,
                                         .doc  = pysel_docstring_doc,
                                     },
                                     {
                                         .name = "__signature__",
                                         .get  = PyObjC_GetCallableSignature,
                                         .doc  = "inspect.Signaturefor a method",
                                     },
                                     {
                                         .name = "isHidden",
                                         .get  = base_hidden,
                                         .set  = base_hidden_setter,
                                         .doc  = base_hidden_doc,
                                     },
                                     {
                                         .name = "isRequired",
                                         .get  = base_required,
                                         .doc  = base_required_doc,
                                     },
                                     {
                                         .name = "isClassMethod",
                                         .get  = base_class_method,
                                         .doc  = base_class_method_doc,
                                     },
                                     {
                                         .name = "definingClass",
                                         .get  = base_class,
                                         .doc  = base_class_doc,
                                     },
                                     {
                                         .name = "__objclass__",
                                         .get  = base_class,
                                         .doc  = base_class_doc,
                                     },
                                     {
                                         .name = "signature",
                                         .get  = base_signature,
                                         .set  = base_signature_setter,
                                         .doc  = base_signature_doc,
                                     },
                                     {
                                         .name = "native_signature",
                                         .get  = base_native_signature,
                                         .doc  = base_native_signature_doc,
                                     },
                                     {
                                         .name = "self",
                                         .get  = base_self,
                                         .doc  = base_self_doc,
                                     },
                                     {
                                         .name = "selector",
                                         .get  = base_selector,
                                         .doc  = base_selector_doc,
                                     },
                                     {
                                         .name = "__name__",
                                         .get  = base_name,
                                         .doc  = base_name_doc,
                                     },
                                     {
                                         .name = NULL /* SENTINEL */
                                     }};

static PyMemberDef pysel_members[] = {
    {
        .name   = "__vectorcalloffset__",
        .type   = T_PYSSIZET,
        .offset = offsetof(PyObjCPythonSelector, base.sel_vectorcall),
        .flags  = READONLY,
    },
    {
        .name = NULL /* SENTINEL */
    }};

static PyType_Slot pysel_slots[] = {
    {.slot = Py_tp_dealloc, .pfunc = (void*)&pysel_dealloc},
    {.slot = Py_tp_repr, .pfunc = (void*)&pysel_repr},
    {.slot = Py_tp_hash, .pfunc = (void*)&pysel_hash},
    {.slot = Py_tp_getattro, .pfunc = (void*)&PyObject_GenericGetAttr},
    {.slot = Py_tp_richcompare, .pfunc = (void*)&pysel_richcompare},
    {.slot = Py_tp_getset, .pfunc = (void*)&pysel_getset},
    {.slot = Py_tp_descr_get, .pfunc = (void*)base_descr_get},
    {.slot = Py_tp_members, .pfunc = (void*)&pysel_members},
    {.slot = Py_tp_methods, .pfunc = (void*)&base_methods},
    {.slot = Py_tp_call, .pfunc = (void*)&PyVectorcall_Call},

    {0, NULL} /* sentinel */
};

static PyType_Spec pysel_spec = {
    .name      = "objc.python_selector",
    .basicsize = sizeof(PyObjCPythonSelector),
    .itemsize  = 0,
    .flags     = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HEAPTYPE | Py_TPFLAGS_IMMUTABLETYPE
                 | Py_TPFLAGS_HAVE_VECTORCALL | Py_TPFLAGS_METHOD_DESCRIPTOR,

    .slots = pysel_slots,
};

const char*
PyObjCSelector_Signature(PyObject* obj)
{
    assert(PyObjCSelector_Check(obj));
    assert(!PyObjCBoundSelector_Check(obj));

    return ((PyObjCSelector*)obj)->sel_python_signature;
}

const char*
PyObjCSelector_GetNativeSignature(PyObject* obj)
{
    assert(PyObjCSelector_Check(obj));
    assert(!PyObjCBoundSelector_Check(obj));

    return ((PyObjCSelector*)obj)->sel_native_signature;
}

Class
PyObjCSelector_GetClass(PyObject* sel)
{
    assert(PyObjCSelector_Check(sel));
    assert(!PyObjCBoundSelector_Check(sel));

    return ((PyObjCSelector*)sel)->sel_class;
}

SEL
PyObjCSelector_GetSelector(PyObject* sel)
{
    assert(PyObjCSelector_Check(sel));

    if (PyObjCBoundSelector_Check(sel)) {
        return ((PyObjCSelector*)PyObjCBoundSelector_SELECTOR(sel))->sel_selector;
    }

    return ((PyObjCSelector*)sel)->sel_selector;
}

int
PyObjCSelector_Required(PyObject* sel)
{
    assert(PyObjCSelector_Check(sel));

    return (PyObjCSelector_GetFlags(sel) & PyObjCSelector_kREQUIRED) != 0;
}

int
PyObjCSelector_IsClassMethod(PyObject* sel)
{
    assert(PyObjCSelector_Check(sel));

    return (PyObjCSelector_GetFlags(sel) & PyObjCSelector_kCLASS_METHOD) != 0;
}

int
PyObjCSelector_IsHidden(PyObject* sel)
{
    assert(PyObjCSelector_Check(sel));

    return (PyObjCSelector_GetFlags(sel) & PyObjCSelector_kHIDDEN) != 0;
}

int
PyObjCSelector_GetFlags(PyObject* sel)
{
    assert(PyObjCSelector_Check(sel));

    if (PyObjCBoundSelector_Check(sel)) {
        return ((PyObjCSelector*)PyObjCBoundSelector_SELECTOR(sel))->sel_flags;
    }

    return ((PyObjCSelector*)sel)->sel_flags;
}

int
PyObjCSelector_Setup(PyObject* module)
{
    PyObject* tmp = PyType_FromSpec(&sel_spec);
    if (unlikely(tmp == NULL)) { // LCOV_BR_EXCL_LINE
        return -1;               // LCOV_EXCL_LINE
    }
    PyObjCSelector_Type = tmp;

    if (unlikely(PyModule_AddObject( // LCOV_BR_EXCL_LINE
                     module, "selector", PyObjCSelector_Type)
                 == -1)) {
        return -1; // LCOV_EXCL_LINE
    }
    Py_INCREF(PyObjCSelector_Type);

    tmp = PyType_FromSpecWithBases(&pysel_spec, PyObjCSelector_Type);
    if (unlikely(tmp == NULL)) { // LCOV_BR_EXCL_LINE
        return -1;               // LCOV_EXCL_LINE
    }
    PyObjCPythonSelector_Type = tmp;

    if (unlikely(PyModule_AddObject( // LCOV_BR_EXCL_LINE
                     module, "python_selector", PyObjCPythonSelector_Type)
                 == -1)) {
        return -1; // LCOV_EXCL_LINE
    }
    Py_INCREF(PyObjCPythonSelector_Type);

    tmp = PyType_FromSpecWithBases(&objcsel_spec, PyObjCSelector_Type);
    if (unlikely(tmp == NULL)) { // LCOV_BR_EXCL_LINE
        return -1;               // LCOV_EXCL_LINE
    }
    PyObjCNativeSelector_Type = tmp;

    if (unlikely(PyModule_AddObject( // LCOV_BR_EXCL_LINE
                     module, "native_selector", PyObjCNativeSelector_Type)
                 == -1)) {
        return -1; // LCOV_EXCL_LINE
    }
    Py_INCREF(PyObjCNativeSelector_Type);

    return 0;
}

int
PyObjCSelector_PostSetup(PyObject* module __attribute__((__unused__)))
{
    /* Ensure that user code cannot create subclasses */
    ((PyTypeObject*)PyObjCSelector_Type)->tp_flags &= ~Py_TPFLAGS_BASETYPE;
    return 0;
}

NS_ASSUME_NONNULL_END
