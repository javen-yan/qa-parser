/*
 * NOTE: the implementation uses PyDict_* APIs whenever possible and falls
 * back to the generic PyObject_* APIs otherwise. We don't use the PyMapping_*
 * APIs because those are incomplete(!).
 */
#include "pyobjc.h"

NS_ASSUME_NONNULL_BEGIN

@implementation OC_PythonDictionary

+ (instancetype _Nullable)dictionaryWithPythonObject:(PyObject*)v
{
    assert(v != NULL);
    return [[[self alloc] initWithPythonObject:v] autorelease];
}

- (instancetype _Nullable)initWithPythonObject:(PyObject*)v
{
    assert(v != NULL);
    self = [super init];
    if (unlikely(self == nil)) // LCOV_BR_EXCL_LINE
        return nil;            // LCOV_EXCL_LINE

    SET_FIELD_INCREF(value, v);
    return self;
}

+ (BOOL)supportsSecureCoding
{
    return NO;
}

- (void)dealloc
{
    if (unlikely(!Py_IsInitialized())) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        [super dealloc];
        return;
        // LCOV_EXCL_STOP
    }

    PyObjC_BEGIN_WITH_GIL
        PyObjC_UnregisterObjCProxy(value, self);
        Py_DECREF(value);

    PyObjC_END_WITH_GIL

    [super dealloc];
}

- (PyObject*)__pyobjc_PythonObject__
{
    assert(value != NULL);
    Py_INCREF(value);
    return value;
}

// LCOV_EXCL_START
/* PythonTransient is used in the implementation of
 * methods written in Python, OC_Python* classes
 * don't have such methods.
 */
- (PyObject*)__pyobjc_PythonTransient__:(int*)cookie
{
    assert(value != NULL);
    *cookie = 0;
    Py_INCREF(value);
    return value;
}
// LCOV_EXCL_STOP

- (NSUInteger)count
{
    Py_ssize_t result;
    if (unlikely(value == NULL)) { // LCOV_BR_EXCL_LINE
        return 0;                  // LCOV_EXCL_LINE
    }

    PyObjC_BEGIN_WITH_GIL
        if (likely(PyAnyDict_CheckExact(value))) {
            result = PyDict_Size(value);
        } else {
            result = PyObject_Length(value);
        }

    PyObjC_END_WITH_GIL

    if (sizeof(Py_ssize_t) > sizeof(NSUInteger)) {
        if (result > (Py_ssize_t)NSUIntegerMax) {
            return NSUIntegerMax;
        }
    }

    return result;
}

- (id _Nullable)objectForKey:key
{
    PyObject* v;
    PyObject* k;
    id        result;

    if (unlikely(value == NULL)) { // LCOV_BR_EXCL_LINE
        return nil;                // LCOV_EXCL_LINE
    }

    PyObjC_BEGIN_WITH_GIL

        if (unlikely(key == NSNull_null)) {
            Py_INCREF(Py_None);
            k = Py_None;
        } else {
            k = id_to_python(key);
            if (k == NULL) {
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE
        }

        if (likely(PyAnyDict_CheckExact(value))) {
            int r = PyDict_GetItemRef(value, k, &v);
            Py_CLEAR(k);
            switch (r) {
            case -1:
                PyObjC_GIL_FORWARD_EXC(); // LCOV_EXCL_LINE
            case 0:
                PyObjC_GIL_RETURN(nil);
            case 1:
                break;
            }

        } else {
            v = PyObject_GetItem(value, k);
            Py_CLEAR(k);
            if (v == nil) {
                if (PyErr_ExceptionMatches(PyExc_KeyError)) {
                    PyErr_Clear();
                    PyObjC_GIL_RETURN(nil);
                } // LCOV_EXCL_LINE
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE
        }

        if (v == Py_None) {
            result = NSNull_null;

        } else if (unlikely(depythonify_python_object(v, &result) == -1)) {
            Py_DECREF(v);
            PyObjC_GIL_FORWARD_EXC();
        } // LCOV_EXCL_LINE
        Py_DECREF(v);

    PyObjC_END_WITH_GIL

    return result;
}

- (void)setObject:(id)val forKey:(id)key
{
    PyObject* v    = NULL;
    PyObject* k    = NULL;
    id        null = NSNull_null;

    PyObjC_BEGIN_WITH_GIL
        if (unlikely(val == null)) {
            Py_INCREF(Py_None);
            v = Py_None;
        } else { // LCOV_EXCL_LINE
            v = id_to_python(val);
            if (unlikely(v == NULL)) {
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE
        }

        if (unlikely(key == nil)) {
            Py_INCREF(Py_None);
            k = Py_None;
        } else if (unlikely(key == null)) {
            Py_INCREF(Py_None);
            k = Py_None;

        } else {
            k = id_to_python(key);
            if (k == NULL) {
                Py_XDECREF(v);
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE
        }

        if (likely(PyDict_CheckExact(value))) {
            if (unlikely(PyDict_SetItem(value, k, v) < 0)) {
                Py_XDECREF(v);
                Py_XDECREF(k);
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE

        } else {
            if (unlikely(PyObject_SetItem(value, k, v) < 0)) {
                Py_XDECREF(v);
                Py_XDECREF(k);
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE
        }

        Py_DECREF(v);
        Py_DECREF(k);

    PyObjC_END_WITH_GIL
}

- (void)removeObjectForKey:(id)key
{
    PyObject* k;

    PyObjC_BEGIN_WITH_GIL
        if (unlikely(key == NSNull_null)) {
            Py_INCREF(Py_None);
            k = Py_None;
        } else {
            k = id_to_python(key);
            if (unlikely(k == NULL)) {
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE
        }

        if (PyDict_CheckExact(value)) {
            if (unlikely(PyDict_DelItem(value, k) < 0)) {
                Py_DECREF(k);
                if (PyErr_ExceptionMatches(PyExc_KeyError)) {
                    PyObjC_LEAVE_GIL;
                    @throw [NSException exceptionWithName:NSInvalidArgumentException
                                                   reason:@"key does not exist"
                                                 userInfo:@{@"key" : key}];
                }
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE

        } else {
            if (unlikely(PyObject_DelItem(value, k) < 0)) {
                Py_DECREF(k);
                if (PyErr_ExceptionMatches(PyExc_KeyError)) {
                    PyObjC_LEAVE_GIL;
                    @throw [NSException exceptionWithName:NSInvalidArgumentException
                                                   reason:@"key does not exist"
                                                 userInfo:@{@"key" : key}];
                }
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE
        }
        Py_DECREF(k);

    PyObjC_END_WITH_GIL
}

- (NSEnumerator*)keyEnumerator
{
    if (unlikely(value == NULL)) { // LCOV_BR_EXCL_LINE
        /* Value could be NULL during ``initWithCoder:``, but AFAIK it
         * is not possible to invoke arbitrary methods in that state.
         */
        return nil; // LCOV_EXCL_LINE

    } else {
        NSEnumerator* result = nil;
        PyObjC_BEGIN_WITH_GIL
            PyObject* args[2] = {NULL, value};

            PyObject* keys = PyObject_VectorcallMethod(
                PyObjCNM_keys, args + 1, 1 | PY_VECTORCALL_ARGUMENTS_OFFSET, NULL);
            if (keys == NULL) {
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE

            PyObject* iter = PyObject_GetIter(keys);
            Py_DECREF(keys);
            if (iter == NULL) {
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE

            result = [OC_PythonEnumerator enumeratorWithPythonObject:iter];
            Py_CLEAR(iter);

        PyObjC_END_WITH_GIL
        return result;
    }
}

- (id)initWithObjects:(const id _Nonnull[])objects
              forKeys:(const id<NSCopying> _Nonnull[])keys
                count:(NSUInteger)count
{
    /* This implementation is needed for our support for the NSCoding
     * protocol, NSDictionary's initWithCoder: will call this method.
     */
    NSUInteger i;

    if (unlikely(count > 0 && (keys == NULL || objects == NULL))) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        [self release];
        return nil;
        // LCOV_EXCL_STOP
    }

    PyObjC_BEGIN_WITH_GIL
        for (i = 0; i < count; i++) {
            PyObject* k;
            PyObject* v;
            int       r;

            if (objects[i] == NSNull_null) {
                v = Py_None;
                Py_INCREF(Py_None);

            } else {
                v = id_to_python(objects[i]);
                if (v == NULL) {
                    PyObjC_GIL_FORWARD_EXC();
                } // LCOV_EXCL_LINE
            }

            if (keys[i] == NSNull_null) {
                k = Py_None;
                Py_INCREF(Py_None);

            } else { // LCOV_EXCL_LINE
                k = id_to_python(keys[i]);
                if (k == NULL) {
                    PyObjC_GIL_FORWARD_EXC();
                } // LCOV_EXCL_LINE
                if (PyObjCUnicode_Check(k)) {
                    PyObject* k2 = PyObject_Str(k);
                    if (unlikely(k2 == NULL)) { // LCOV_BR_EXCL_LINE
                        // LCOV_EXCL_START
                        Py_DECREF(k);
                        PyObjC_GIL_FORWARD_EXC();
                        // LCOV_EXCL_STOP
                    } // LCOV_EXCL_LINE
                    PyUnicode_InternInPlace(&k2);
                    Py_DECREF(k);
                    k = k2;
                }
            }

            r = PyDict_SetItem(value, k, v);
            Py_DECREF(k);
            Py_DECREF(v);

            if (r == -1) {
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE
        }
    PyObjC_END_WITH_GIL
    return self;
}

/*
 * Helper method for initWithCoder, needed to deal with
 * recursive objects (e.g. o.value = o)
 */
- (void)pyobjcSetValue:(NSObject*)other
{
    PyObjC_BEGIN_WITH_GIL
        PyObject* v = id_to_python(other);

        /* 'other' is a serialized python mapping value
         * (not a 'real' Cocoa instance). Those can
         * always be converted back into the corresponding
         * Python value.
         */
        if (unlikely(v != NULL)) { // LCOV_BR_EXCL_LINE
            SET_FIELD(value, v);   // LCOV_EXCL_LINE
        }
    PyObjC_END_WITH_GIL
}

- (id _Nullable)initWithCoder:(NSCoder*)coder
{
    int code;
#if PY_VERSION_HEX >= 0x030f00a7
    int isfrozen = 0;
#endif
    if ([coder allowsKeyedCoding]) {
        code = [coder decodeInt32ForKey:@"pytype"];
#if PY_VERSION_HEX >= 0x030f00a7
        if ([coder containsValueForKey:@"isfrozen"]) {
            isfrozen = [coder decodeInt32ForKey:@"isfrozen"];
        }
#endif
    } else {
#if MAC_OS_X_VERSION_MIN_REQUIRED < MAC_OS_X_VERSION_10_13 && PyObjC_BUILD_RELEASE >= 1013
        /* Old deployment target, modern SDK */
        if (@available(macOS 10.13, *)) {
            [coder decodeValueOfObjCType:@encode(int) at:&code size:sizeof(code)];
        } else {
            CLANG_SUPPRESS
            [coder decodeValueOfObjCType:@encode(int) at:&code];
        }
#elif PyObjC_BUILD_RELEASE >= 1013
        /* Modern deployment target */
        [coder decodeValueOfObjCType:@encode(int) at:&code size:sizeof(code)];
#else
        /* Deployment target is ancient and SDK is old */
        [coder decodeValueOfObjCType:@encode(int) at:&code];
#endif
    }

    switch (code) { // LCOV_BR_EXCL_LINE
    case 1:
        PyObjC_BEGIN_WITH_GIL
            value = PyDict_New();
            if (unlikely(value == NULL)) { // LCOV_BR_EXCL_LINE
                PyObjC_GIL_FORWARD_EXC();  // LCOV_EXCL_LINE
            } // LCOV_EXCL_LINE

        PyObjC_END_WITH_GIL

        self = [super initWithCoder:coder];
#if PY_VERSION_HEX >= 0x030f00a7
        if (isfrozen) {
            PyObjC_BEGIN_WITH_GIL
                PyObject* new_value = PyFrozenDict_New(value);
                if (new_value == NULL) {      // LCOV_BR_EXCL_LINE
                    PyObjC_GIL_FORWARD_EXC(); // LCOV_EXCL_LINE
                } // LCOV_EXCL_LINE
                PyObject* old_value = value;

                PyObjC_UnregisterObjCProxy(value, self);
                value = new_value;
                Py_CLEAR(old_value);

                id actual = PyObjC_RegisterObjCProxy(value, self);
                [self release];
                self = actual;
            PyObjC_END_WITH_GIL
        }
#endif
        return self;

    case 2:
        PyObjC_BEGIN_WITH_GIL
            PyObject* decoded = PyObjC_decodeWithCoder(coder, self);
            if (decoded == NULL) {
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE

            SET_FIELD(value, decoded);

            id actual = PyObjC_RegisterObjCProxy(value, self);
            [self release];
            self = actual;
        PyObjC_END_WITH_GIL

        return self;

    default:
        // LCOV_EXCL_START
        @throw [NSException exceptionWithName:NSInvalidArgumentException
                                       reason:@"decoding Python objects is not supported"
                                     userInfo:nil];
        // LCOV_EXCL_STOP
    }
}

- (Class)classForCoder
{
#if PY_VERSION_HEX >= 0x030f00a7
    if (unlikely(value && PyFrozenDict_CheckExact(value))) { // LCOV_BR_EXCL_LINE
        return [NSDictionary class];
    }
#endif
    if (unlikely(value && PyDict_CheckExact(value))) { // LCOV_BR_EXCL_LINE
        return [NSMutableDictionary class];
    } else {
        return [OC_PythonDictionary class];
    }
}

- (Class _Nullable)classForKeyedArchiver
{
    return [OC_PythonDictionary class];
}

+ (NSArray*)classFallbacksForKeyedArchiver
{
    return [NSArray arrayWithObject:@"NSDictionary"];
}

- (void)encodeWithCoder:(NSCoder*)coder
{
    if (PyAnyDict_CheckExact(value)) {
        if ([coder allowsKeyedCoding]) {
            [coder encodeInt32:1 forKey:@"pytype"];
#if PY_VERSION_HEX >= 0x030f00a7
            if (unlikely(PyFrozenDict_CheckExact(value))) {
                [coder encodeInt32:1 forKey:@"isfrozen"];
            }
#endif
        }
        [super encodeWithCoder:coder];

    } else {
        if ([coder allowsKeyedCoding]) {
            [coder encodeInt32:2 forKey:@"pytype"];

        } else {
            int v = 2;
            [coder encodeValueOfObjCType:@encode(int) at:&v];
        }
        PyObjC_BEGIN_WITH_GIL
            if (PyObjC_encodeWithCoder(value, coder) == -1) {
                PyObjC_GIL_FORWARD_EXC();
            } // LCOV_EXCL_LINE
        PyObjC_END_WITH_GIL
    }
}

- (id)copyWithZone:(NSZone* _Nullable)zone
{
    NSObject* result;

    PyObjC_BEGIN_WITH_GIL
        PyObject* copy = PyObjC_Copy(value);
        if (copy == NULL) {
            PyObjC_GIL_FORWARD_EXC();
        } // LCOV_EXCL_LINE

        if (depythonify_python_object(copy, &result) == -1) {
            Py_DECREF(copy);
            PyObjC_GIL_FORWARD_EXC();
        } // LCOV_EXCL_LINE
        Py_DECREF(copy);
    PyObjC_END_WITH_GIL

    [result retain];
    return result;
}

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-parameter"
- (id)mutableCopyWithZone:(NSZone* _Nullable)zone
{
    NSObject* result;

    PyObjC_BEGIN_WITH_GIL
        PyObject* copy = PyDict_New();
        if (unlikely(copy == NULL)) { // LCOV_BR_EXCL_LINE
            PyObjC_GIL_FORWARD_EXC(); // LCOV_EXCL_LINE
        } // LCOV_EXCL_LINE

        int r = PyDict_Update(copy, value);
        if (r == -1) {
            PyObjC_GIL_FORWARD_EXC();
        } // LCOV_EXCL_LINE

        if (unlikely(depythonify_python_object( // LCOV_BR_EXCL_LINE
                         copy, &result)
                     == -1)) {
            // LCOV_EXCL_START
            Py_DECREF(copy);
            PyObjC_GIL_FORWARD_EXC();
            // LCOV_EXCL_STOP
        } // LCOV_EXCL_LINE
        Py_DECREF(copy);

    PyObjC_END_WITH_GIL

    [result retain];
    return result;
}
#pragma clang diagnostic pop

@end /* interface OC_PythonDictionary */

NS_ASSUME_NONNULL_END
