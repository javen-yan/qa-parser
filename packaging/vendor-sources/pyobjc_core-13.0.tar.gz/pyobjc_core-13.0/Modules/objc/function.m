/*
 * Wrapper for simple global functions. Simple functions are those without
 * arguments that require additional effort.
 */
#include "pyobjc.h"

NS_ASSUME_NONNULL_BEGIN

static PyObject* PyObjCFunc_Type;
#define PyObjCFunction_Check(value) Py_IS_TYPE((value), (PyTypeObject*)PyObjCFunc_Type)

int(PyObjCFunction_Check)(PyObject* value) { return PyObjCFunction_Check(value); }

typedef struct {
    PyObject_HEAD

    ffi_cif* _Nullable cif;
    PyObjC_FunctionCallFunc _Nullable invoker;
    PyObjCMethodSignature* methinfo;
    void*                  function;
    PyObject* _Nullable doc;
    PyObject* _Nullable name;
    PyObject* _Nullable module;
    vectorcallfunc vectorcall;
} func_object;

static PyObject* _Nullable func_metadata(PyObject* _self)
{
    func_object* self = (func_object*)_self;
    PyObject*    result;
    result = PyObjCMethodSignature_AsDict(self->methinfo);
    if (unlikely(result == NULL)) { // LCOV_BR_EXCL_LINE
        return NULL;                // LCOV_EXCL_LINE
    }
    if (self->doc) {
        if (unlikely(PyDict_SetItem( // LCOV_BR_EXCL_LINE
                         result, PyObjCNM___doc__, self->doc)
                     == -1)) {
            Py_DECREF(result); // LCOV_EXCL_LINE
            return NULL;       // LCOV_EXCL_LINE
        }
    }
#if PY_VERSION_HEX >= 0x030f00a7
    PyObject* tmp = PyFrozenDict_New(result);
    Py_CLEAR(result);
    return tmp;

#else
    return result;
#endif
}

static PyMethodDef func_methods[] = {
    {.ml_name  = "__metadata__",
     .ml_meth  = (PyCFunction)func_metadata,
     .ml_flags = METH_NOARGS,
     .ml_doc   = "Return a dict that describes the metadata for this function."},
    {.ml_name  = "__class_getitem__",
     .ml_meth  = (PyCFunction)Py_GenericAlias,
     .ml_flags = METH_O | METH_CLASS,
     .ml_doc   = "See PEP 585"},
    {
        .ml_name = NULL /* SENTINEL */
    }};

static PyGetSetDef func_getset[] = {{
                                        .name = "__doc__",
                                        .get  = PyObjC_GetCallableDocString,
                                        .doc  = "Documentation for a function",
                                    },
                                    {
                                        .name = "__signature__",
                                        .get  = PyObjC_GetCallableSignature,
                                        .doc  = "inspect.Signature for a function",
                                    },
                                    {
                                        .name = NULL /* SENTINEL */
                                    }};

static PyMemberDef func_members[] = {{
                                         .name   = "__name__",
                                         .type   = T_OBJECT,
                                         .offset = offsetof(func_object, name),
                                         .flags  = READONLY,
                                     },
                                     {
                                         .name   = "__module__",
                                         .type   = T_OBJECT,
                                         .offset = offsetof(func_object, module),
                                     },
                                     {
                                         .name   = "__vectorcalloffset__",
                                         .type   = T_PYSSIZET,
                                         .offset = offsetof(func_object, vectorcall),
                                         .flags  = READONLY,
                                     },
                                     {
                                         .name = NULL /* SENTINEL */
                                     }};

static PyObject* _Nullable func_repr(PyObject* _self)
{
    func_object* self = (func_object*)_self;

    if (self->name == NULL) {
        return PyUnicode_FromFormat("<objc.function at %p>", self);
    } else {
        return PyUnicode_FromFormat("<objc.function %R at %p>", self->name, self);
    }
}

static PyObject* _Nullable func_vectorcall_invoker(PyObject* s, PyObject* const* args,
                                                   size_t nargsf,
                                                   PyObject* _Nullable kwnames)
{
    func_object* self = (func_object*)s;

    if (PyObjC_CheckNoKwnames(s, kwnames) == -1) {
        return NULL;
    }

    if (version_is_deprecated(self->methinfo->deprecated)) {
        char buf[128];

        snprintf(buf, 128, "%s() is a deprecated API (macOS %d.%d)", // LCOV_BR_EXCL_LINE
                 (self->name ? PyUnicode_AsUTF8(self->name) : "objc.function instance"),
                 self->methinfo->deprecated / 100, self->methinfo->deprecated % 100);

        if (PyErr_Warn(PyObjCExc_DeprecationWarning, buf) < 0) {
            return NULL;
        }
    }

    if (self->methinfo->suggestion != NULL) {
        PyErr_SetObject(PyExc_TypeError, self->methinfo->suggestion);
        return NULL;
    }

    return self->invoker(s, args, PyVectorcall_NARGS(nargsf));
}

static PyObject* _Nullable func_vectorcall(PyObject* s, PyObject* const* args,
                                           size_t nargsf, PyObject* _Nullable kwnames)
{
    func_object* self = (func_object*)s;
    Py_ssize_t   byref_in_count;
    Py_ssize_t   byref_out_count;
    Py_ssize_t   plain_count;
    Py_ssize_t   argbuf_len;
    int          r;
    Py_ssize_t   cif_arg_count;
    BOOL         variadicAllArgs = NO;

    unsigned char*    argbuf = NULL;
    ffi_type*         arglist[MAX_ARGCOUNT];
    void*             values[MAX_ARGCOUNT];
    void*             byref[MAX_ARGCOUNT]      = {0};
    struct byref_attr byref_attr[MAX_ARGCOUNT] = {BYREF_ATTR_INT};
    ffi_cif           cif;
    ffi_cif*          cifptr;

    PyObject* retval = NULL;

    if (PyObjC_CheckNoKwnames(s, kwnames) == -1) {
        return NULL;
    }

    /*
     * The PY_VECTORCALL_ARGUMENTS_OFFSET feature is not used by this function.
     * fetch the raw number of arguments to make it possible to ignore that flag
     * in the rest of the implementation.
     */
    nargsf = PyVectorcall_NARGS(nargsf);

    if (version_is_deprecated(self->methinfo->deprecated)) {
        char buf[128];

        snprintf(buf, 128, "%s() is a deprecated API (macOS %d.%d)", // LCOV_BR_EXCL_LINE
                 (self->name ? PyUnicode_AsUTF8(self->name) : "objc.function instance"),
                 self->methinfo->deprecated / 100, self->methinfo->deprecated % 100);

        if (PyErr_Warn(PyObjCExc_DeprecationWarning, buf) < 0) {
            return NULL;
        }
    }

    if (self->methinfo->suggestion != NULL) {
        PyErr_SetObject(PyExc_TypeError, self->methinfo->suggestion);
        return NULL;
    }

    if (Py_SIZE(self->methinfo) >= 63) {
        PyErr_Format(PyObjCExc_Error,
                     "wrapping a function with %ld arguments, at most 62 "
                     "are supported",
                     Py_SIZE(self->methinfo));
        return NULL;
    }

    argbuf_len = PyObjCRT_SizeOfReturnType(self->methinfo->rettype->type);
    argbuf_len = align(argbuf_len, sizeof(void*));
    r = PyObjCFFI_CountArguments(self->methinfo, 0, &byref_in_count, &byref_out_count,
                                 &plain_count, &argbuf_len, &variadicAllArgs);
    if (unlikely(r == -1)) { // LCOV_BR_EXCL_LINE
        return NULL;         // LCOV_EXCL_LINE
    }

    variadicAllArgs |=
        self->methinfo->variadic
        && (self->methinfo->null_terminated_array || self->methinfo->arrayArg != -1);

    if (variadicAllArgs) {
        if (byref_in_count != 0 || byref_out_count != 0) {
            PyErr_Format(PyExc_TypeError, "variadic with by-ref args not supported");
            return NULL;
        }

        if (nargsf < (size_t)Py_SIZE(self->methinfo)) {
            PyErr_Format(PyExc_TypeError, "Need at least %ld arguments, got %zu",
                         Py_SIZE(self->methinfo), nargsf);
            return NULL;
        }

    } else if (nargsf != (size_t)Py_SIZE(self->methinfo)) {
        PyErr_Format(PyExc_TypeError, "Need %ld arguments, got %zu",
                     Py_SIZE(self->methinfo), nargsf);
        return NULL;
    }

    argbuf = PyMem_Malloc(argbuf_len);
    if (unlikely(argbuf == NULL)) { // LCOV_BR_EXCL_LINE
        PyErr_NoMemory();           // LCOV_EXCL_LINE
        return NULL;                // LCOV_EXCL_LINE
    }

    cif_arg_count = PyObjCFFI_ParseArguments(
        self->methinfo, 0, args, nargsf,
        align(PyObjCRT_SizeOfReturnType(self->methinfo->rettype->type), sizeof(void*)),
        argbuf, argbuf_len, byref, byref_attr, arglist, values);

    if (cif_arg_count == -1) {
        goto error;
    }

    if (variadicAllArgs) {
#if PyObjC_BUILD_RELEASE >= 1015

#ifdef __arm64__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability-new"
#endif

#ifndef __arm64__
        if (@available(macOS 10.15, *)) {
#endif
            r = ffi_prep_cif_var(
                &cif, FFI_DEFAULT_ABI, (int)Py_SIZE(self->methinfo), (int)cif_arg_count,
                PyObjCFFI_Typestr2FFI(self->methinfo->rettype->type), arglist);
#ifndef __arm64__
        } else
#endif
#endif

#ifndef __arm64__
        {
            r = ffi_prep_cif(&cif, FFI_DEFAULT_ABI, (int)cif_arg_count,
                             PyObjCFFI_Typestr2FFI(self->methinfo->rettype->type),
                             arglist);
        }

#else
#pragma clang diagnostic pop
#endif

        if (unlikely(r != FFI_OK)) { // LCOV_BR_EXCL_LINE
            // LCOV_EXCL_START
            PyErr_Format(PyObjCExc_Error, "Cannot create FFI CIF for %s: %s",
                         self->methinfo->signature, PyObjC_ffi_status_str((ffi_status)r));
            goto error;
            // LCOV_EXCL_STOP
        }
        cifptr = &cif;

    } else {
        cifptr = self->cif;
    }

    Py_BEGIN_ALLOW_THREADS
        @try {
            ffi_call(cifptr, FFI_FN(self->function), argbuf, values);

        } @catch (NSObject* localException) {   // LCOV_BR_EXCL_LINE
            PyObjCErr_FromObjC(localException); // LCOV_BR_EXCL_LINE
        }
    Py_END_ALLOW_THREADS

    if (PyErr_Occurred()) {
        goto error;
    }

    retval = PyObjCFFI_BuildResult(self->methinfo, 0, argbuf, byref, byref_attr,
                                   byref_out_count, values);

error:
    if (variadicAllArgs) {
        PyObjCFFI_FreeByRef(Py_SIZE(self->methinfo) + nargsf, byref, byref_attr);

    } else {
        PyObjCFFI_FreeByRef(Py_SIZE(self->methinfo), byref, byref_attr);
    }

    assert(argbuf != NULL);
    PyMem_Free(argbuf);
    return retval;
}

/*
 * A variant of func_vectorcall that only handles "simple" functions. This allows
 * for a number of simplifications that significantly speed up functions calls
 * (about 50% faster on my M1 laptop)
 */
static PyObject* _Nullable func_vectorcall_simple(PyObject* s, PyObject* const* args,
                                                  size_t nargsf,
                                                  PyObject* _Nullable kwnames)
{
    func_object* self = (func_object*)s;

    unsigned char argbuf[SHORTCUT_MAX_ARGBUF];
    void*         values[MAX_ARGCOUNT_SIMPLE];

    assert(self->methinfo->shortcut_signature);

    if (PyObjC_CheckNoKwnames(s, kwnames) == -1) {
        return NULL;
    }

    /*
     * The PY_VECTORCALL_ARGUMENTS_OFFSET feature is not used by this function.
     * fetch the raw number of arguments to make it possible to ignore that flag
     * in the rest of the implementation.
     */
    nargsf = PyVectorcall_NARGS(nargsf);

    if (version_is_deprecated(self->methinfo->deprecated)) {
        char buf[128];

        snprintf(buf, 128, "%s() is a deprecated API (macOS %d.%d)",
                 (self->name ? PyUnicode_AsUTF8(self->name) : "objc.function instance"),
                 self->methinfo->deprecated / 100, self->methinfo->deprecated % 100);
        if (PyErr_Warn(PyObjCExc_DeprecationWarning, buf) < 0) {
            return NULL;
        }
    }

    if (unlikely(nargsf != (size_t)Py_SIZE(self->methinfo))) {
        PyErr_Format(PyExc_TypeError, "Need %ld arguments, got %ld",
                     Py_SIZE(self->methinfo), nargsf);
        return NULL;
    }
    if (unlikely(PyObjCFFI_ParseArguments_Simple(
                     self->methinfo, 0, args, nargsf,
                     align(PyObjCRT_SizeOfReturnType(self->methinfo->rettype->type),
                           sizeof(void*)),
                     argbuf, sizeof(argbuf), values)
                 == -1)) {

        goto error;
    }

    Py_BEGIN_ALLOW_THREADS
        @try {
            ffi_call(self->cif, FFI_FN(self->function), argbuf, values);
        } @catch (id localException) {                     // LCOV_BR_EXCL_LINE
            PyObjCErr_FromObjC((NSObject*)localException); // LCOV_BR_EXCL_LINE
        }
    Py_END_ALLOW_THREADS

    if (unlikely(PyErr_Occurred())) {
        goto error;
    }

    return PyObjCFFI_BuildResult_Simple(self->methinfo, argbuf);

error:
    return NULL;
}

static void
func_dealloc(PyObject* s)
{
    func_object* self = (func_object*)s;

    Py_XDECREF(self->doc);
    Py_XDECREF(self->name);
    Py_XDECREF(self->module);
    Py_XDECREF(self->methinfo);
    if (self->cif != NULL) {
        PyObjCFFI_FreeCIF(self->cif);
    }
    PyTypeObject* tp = Py_TYPE(s);
    PyObject_Free(s);
    Py_DECREF(tp);
}

static PyObject*
func_descr_get(PyObject* self, PyObject* _Nullable obj __attribute__((__unused__)),
               PyObject* _Nullable type __attribute__((__unused__)))
{
    Py_INCREF(self);
    return self;
}

static PyType_Slot func_slots[] = {
    {.slot = Py_tp_getattro, .pfunc = (void*)&PyObject_GenericGetAttr},
    {.slot = Py_tp_setattro, .pfunc = (void*)&PyObject_GenericSetAttr},
    {.slot = Py_tp_methods, .pfunc = (void*)&func_methods},
    {.slot = Py_tp_members, .pfunc = (void*)&func_members},
    {.slot = Py_tp_descr_get, .pfunc = (void*)&func_descr_get},
    {.slot = Py_tp_dealloc, .pfunc = (void*)&func_dealloc},
    {.slot = Py_tp_repr, .pfunc = (void*)&func_repr},
    {.slot = Py_tp_getset, .pfunc = (void*)&func_getset},
    {.slot = Py_tp_call, .pfunc = (void*)&PyVectorcall_Call},

    {0, NULL} /* sentinel */
};

static PyType_Spec func_spec = {
    .name      = "objc.function",
    .basicsize = sizeof(func_object),
    .itemsize  = 0,
    .flags     = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HEAPTYPE | Py_TPFLAGS_IMMUTABLETYPE
                 | Py_TPFLAGS_HAVE_VECTORCALL | Py_TPFLAGS_DISALLOW_INSTANTIATION,
    .slots     = func_slots,
};

PyObject* _Nullable PyObjCFunc_WithMethodSignature(PyObject* _Nullable name, void* func,
                                                   PyObjCMethodSignature* methinfo)
{
    func_object* result;

    assert(!name || PyUnicode_Check(name));

    result = PyObject_NEW(func_object, (PyTypeObject*)PyObjCFunc_Type);
    if (unlikely(result == NULL)) // LCOV_BR_EXCL_LINE
        return NULL;              // LCOV_EXCL_LINE

    result->vectorcall = func_vectorcall;
    result->function   = func;
    result->doc        = NULL;
    result->name       = name;
    Py_XINCREF(name);
    result->module   = NULL;
    result->methinfo = methinfo;
    Py_XINCREF(methinfo);
    if (result->methinfo->shortcut_signature) {
        result->vectorcall = func_vectorcall_simple;
    }
    result->cif = NULL;

    result->invoker = PyObjC_FindFunctionCaller(func, methinfo->signature);
    if (unlikely(result->invoker == NULL && PyErr_Occurred())) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        Py_DECREF(result);
        return NULL;
        // LCOV_EXCL_STOP
    } else if (result->invoker != NULL) {
        result->vectorcall = func_vectorcall_invoker;
        return (PyObject*)result;
    }

    ffi_cif* cif = PyObjCFFI_CIFForSignature(result->methinfo);
    if (cif == NULL) {
        Py_DECREF(result);
        return NULL;
    }
    result->cif = cif;

    return (PyObject*)result;
}

PyObject* _Nullable PyObjCFunc_New(PyObject* name, void* func, const char* signature,
                                   PyObject* _Nullable doc, PyObject* meta)
{
    func_object* result;

    assert(!name || PyUnicode_Check(name));
    if (doc && PyUnicode_GetLength(doc) == 0) {
        /* Ignore empty docstring */
        doc = NULL;
    }

    result = PyObject_New(func_object, (PyTypeObject*)PyObjCFunc_Type);
    if (unlikely(result == NULL)) // LCOV_BR_EXCL_LINE
        return NULL;              // LCOV_EXCL_LINE

    result->vectorcall = func_vectorcall;
    result->function   = func;

    /* set later in this function */
    result->doc      = (PyObject* _Nonnull)NULL;
    result->name     = (PyObject* _Nonnull)NULL;
    result->module   = NULL;
    result->methinfo = (PyObjCMethodSignature* _Nonnull)NULL;
    result->cif      = NULL;

    PyObjCMethodSignature* methinfo =
        PyObjCMethodSignature_WithMetaData(signature, meta, NO);
    if (methinfo == NULL) {
        Py_DECREF(result);
        return NULL;
    }
    result->methinfo = methinfo;

    if (result->methinfo->shortcut_signature) {
        result->vectorcall = func_vectorcall_simple;
    }

    SET_FIELD_INCREF(result->doc, doc);
    SET_FIELD_INCREF(result->name, name);

    result->invoker = PyObjC_FindFunctionCaller(func, methinfo->signature);
    if (result->invoker != NULL) {
        result->vectorcall = func_vectorcall_invoker;
        return (PyObject*)result;
    } else if (unlikely(PyErr_Occurred())) { // LCOV_BR_EXCL_LINE
        // LCOV_EXCL_START
        Py_DECREF(result);
        return NULL;
        // LCOV_EXCL_STOP
    }

    result->cif = PyObjCFFI_CIFForSignature(result->methinfo);
    if (unlikely(result->cif == NULL)) { // LCOV_BR_EXCL_LINE
        Py_DECREF(result);               // LCOV_EXCL_LINE
        return NULL;                     // LCOV_EXCL_LINE
    }

    return (PyObject*)result;
}

PyObjCMethodSignature* _Nullable PyObjCFunc_GetMethodSignature(PyObject* func)
{
    Py_INCREF(((func_object*)func)->methinfo);
    return ((func_object*)func)->methinfo;
}

void*
PyObjCFunc_GetCallable(PyObject* func)
{
    return ((func_object*)func)->function;
}

int
PyObjCFunc_Setup(PyObject* module)
{
    PyObjCFunc_Type = PyType_FromSpec(&func_spec);
    if (unlikely(PyObjCFunc_Type == NULL)) { // LCOV_BR_EXCL_LINE
        return -1;                           // LCOV_EXCL_LINE
    }

    if (unlikely(PyModule_AddObject( // LCOV_BR_EXCL_LINE
                     module, "function", PyObjCFunc_Type)
                 == -1)) {
        return -1; // LCOV_EXCL_LINE
    }
    Py_INCREF(PyObjCFunc_Type);

    return 0;
}

NS_ASSUME_NONNULL_END
